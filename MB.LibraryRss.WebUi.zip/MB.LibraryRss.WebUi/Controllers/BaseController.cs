﻿namespace MB.LibraryRss.WebUi.Controllers
{
  using System.Web.Mvc;

  public class BaseController : Controller
  {    
  }
}
